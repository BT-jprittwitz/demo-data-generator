# -*- coding: utf-8 -*-
from odoo.fields import Command


def post_init_hook(env):
    """Traegt den UI-Login-Admin (base.user_admin) explizit in company_ids der neu
    angelegten Demo-Company ein und setzt sie als seine aktive Company, damit alle
    Demo-Daten direkt nach der Installation ohne manuellen Zwischenschritt sichtbar sind
    (siehe Kommentar oben / Modul-README fuer den verifizierten Hintergrund)."""
    company = env.ref("bt_demo_mfg.demo_company", raise_if_not_found=False)
    admin = env.ref("base.user_admin", raise_if_not_found=False)
    if not company or not admin:
        return
    admin.write({
        "company_ids": [Command.link(company.id)],
        "company_id": company.id,
    })
