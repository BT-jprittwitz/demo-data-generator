# -*- coding: utf-8 -*-
{
    "name": "Demo Data - Produzierender Kunde (Company, Stueckliste, Angebote, Auftraege)",
    "version": "19.0.1.0.0",
    "category": "Manufacturing",
    "summary": "Proof-of-concept: eigene Company, Kontakte, Produkte, Stuecklisten, Angebotsvorlage, Beispielauftraege",
    "description": """
        Beispielhaftes Demo-Datenmodul fuer einen produzierenden Kunden:
        - 1 neue Company (Kundenname, Adresse) - alle Daten sind darauf geschluesselt
        - 3 Kontakte
        - 7 Produkte (4 Komponenten, 2 Fertigprodukte, 1 Dienstleistung)
        - 2 Stuecklisten fuer die Fertigprodukte
        - 1 Angebotsvorlage mit je einer Position pro Produktart
        - 3 Beispiel-Verkaufsauftraege
    """,
    "author": "braintec",
    "website": "https://www.braintec.com",
    "depends": ["sale_management", "mrp"],
    "data": [
        "data/res_company_data.xml",
        "data/res_partner_data.xml",
        "data/product_data.xml",
        "data/mrp_bom_data.xml",
        "data/sale_order_quotation_data.xml",
        "data/sale_order_examples_data.xml",
    ],
    "demo": [],
    "post_init_hook": "post_init_hook",
    "installable": True,
    "auto_install": False,
    "application": False,
    "license": "LGPL-3",
}
